<?php
/** Administrator lifecycle adapter. Existing users remain the authentication identity. */
declare(strict_types=1);
defined('CWP_BOOT') || exit;

use CajunWebPro\Foundation\Access\AccessContext;
use CajunWebPro\Foundation\Access\PermissionPolicy;
use CajunWebPro\Foundation\Invitations\StaffInvitationStore;

foreach (['access/AuthorizationVersion','access/AccessContext','access/MailboxGrant','access/PermissionPolicy','invitations/IssuedInvitation','invitations/StaffInvitationStore'] as $class) {
    require_once __DIR__.'/foundation/'.$class.'.php';
}
function staff_ready(): bool { return setting('staff_schema_version') === '1'; }
function staff_schema(string $prefix): array {
    if (!preg_match('/^[a-zA-Z][a-zA-Z0-9_]{1,19}$/D',$prefix)) throw new InvalidArgumentException('Invalid prefix.');
    return [
        'staff_profiles'=>'CREATE TABLE `'.$prefix.'staff_profiles` (user_id INT UNSIGNED PRIMARY KEY,role VARCHAR(20) NOT NULL,enabled TINYINT NOT NULL,permissions TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'staff_invitations'=>StaffInvitationStore::createTableSql($prefix.'staff_invitations'),
    ];
}
function staff_permissions(): array { return ['payments.manage'=>'Invoice payment requests and verified external receipts (also needs client access)', 'catalog.manage'=>'Service catalog, internal costs and catalog invoices (also needs client access)', 'website.manage'=>'Website, portfolio and inquiries','clients.manage'=>'Client projects, files and manual invoices','support.login'=>'Open permitted client portals for support','support.write'=>'Send Studio messages and upload files during support','support.download'=>'Download private files during support']; }
function staff_profile(array $user): ?array {
    if (!staff_ready()) return $user + ['role'=>'owner','enabled'=>1,'permissions'=>'[]']; // Existing access until explicit upgrade.
    $p=one('SELECT role,enabled,permissions FROM '.table('staff_profiles').' WHERE user_id=?',[$user['id']]);
    if (!$p || (int)$p['enabled']!==1 || !in_array($p['role'],['owner','administrator'],true)) return null;
    $permissions=json_decode($p['permissions'],true);
    if (!is_array($permissions) || !array_is_list($permissions) || array_filter($permissions,fn($v)=>!is_string($v)||!array_key_exists($v,staff_permissions()))) return null;
    return array_merge($user,$p);
}
function staff_can(string $permission,?array $user=null): bool {
    $user=$user ?? admin_user();
    if (!$user) return false;
    $profile=staff_profile($user);
    if (!$profile) return false;
    $context=new AccessContext((string)$profile['id'],'staff',$profile['role'],true,(string)$profile['auth_version'],(string)($_SESSION['auth_version']??''),json_decode($profile['permissions'],true));
    return (new PermissionPolicy())->allows($context,$permission);
}
function staff_require(string $permission): array {
    $user=require_admin();
    if (!staff_can($permission,$user)) throw new RuntimeException('Your account does not have access to this action.');
    return $user;
}
/** All credential/owner transitions share one DB-scoped mutex, including activation and reset. */
function staff_locked(callable $work): mixed {
    $key='cwp-staff-'.substr(hash('sha256',config()['db']['name'].'|'.config()['db']['prefix']),0,40);
    if ((int)query('SELECT GET_LOCK(?,5)',[$key])->fetchColumn()!==1) throw new RuntimeException('Another account change is in progress. Please retry.');
    try { return $work(); } finally { query('SELECT RELEASE_LOCK(?)',[$key]); }
}
function staff_transaction(callable $work): mixed {
    if (db()->inTransaction()) throw new LogicException('Account transaction must not be nested.');
    db()->beginTransaction();
    try { $result=$work();db()->commit();return $result; }
    catch (Throwable $e) { if (db()->inTransaction()) db()->rollBack();throw $e; }
}
function staff_store(): StaffInvitationStore { return new StaffInvitationStore(db(),config()['db']['prefix'].'staff_invitations'); }
function staff_seed_owner(int $id): void {
    query('INSERT INTO '.table('staff_profiles').' (user_id,role,enabled,permissions) VALUES (?,\'owner\',1,\'[]\')',[$id]);
    save_setting('staff_schema_version','1');
}
function staff_validate_schema(string $name): void {
    $expected=$name==='staff_profiles'
        ? ['user_id'=>['int unsigned','NO'],'role'=>['varchar(20)','NO'],'enabled'=>['tinyint','NO'],'permissions'=>['text','NO']]
        : ['subject_id'=>['varchar(128)','NO'],'token_hash'=>['char(64)','NO'],'auth_version'=>['varchar(64)','NO'],'expires_at'=>['bigint unsigned','NO'],'consumed_at'=>['bigint unsigned','YES']];
    $row=one('SELECT ENGINE FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?',[config()['db']['prefix'].$name]);
    $cols=all('SHOW COLUMNS FROM '.table($name));$actual=[];
    foreach ($cols as $c) $actual[$c['Field']]=[preg_replace('/\b(tinyint|int|bigint)\([0-9]+\)/','$1',strtolower($c['Type'])),$c['Null']];
    $keys=[];foreach(all('SHOW INDEX FROM '.table($name)) as $k) if((int)$k['Non_unique']===0)$keys[$k['Key_name']][(int)$k['Seq_in_index']]=$k['Column_name'];
    $required=$name==='staff_profiles'?['PRIMARY'=>[1=>'user_id']]:['PRIMARY'=>[1=>'subject_id'],'token_hash'=>[1=>'token_hash']];
    if (strtolower($row['ENGINE']??'')!=='innodb'||$actual!==$expected) throw new RuntimeException('Incompatible '.$name.' table. Existing data was not replaced.');
    foreach($required as $key=>$fields)if(($keys[$key]??[])!==$fields)throw new RuntimeException('Incompatible '.$name.' keys. Existing data was not replaced.');
    if($name==='staff_invitations')foreach(all('SHOW FULL COLUMNS FROM '.table($name)) as $c)if(in_array($c['Field'],['subject_id','token_hash','auth_version'],true)&&$c['Collation']!=='ascii_bin')throw new RuntimeException('Incompatible invitation collation.');
}
function staff_migrate(int $ownerId,#[\SensitiveParameter] string $password): void {
    staff_locked(function() use($ownerId,$password): void {
        $actor=require_admin();
        if (!password_verify($password,$actor['password_hash'])) throw new InvalidArgumentException('Your current password is not correct.');
        if (staff_ready()&&!staff_can('staff.manage',$actor)) throw new RuntimeException('Only an owner can verify administrator access.');
        $chosen=one('SELECT id,password_hash FROM '.table('users').' WHERE id=?',[$ownerId]);
        if (!$chosen||$chosen['password_hash']==='') throw new InvalidArgumentException('Choose an existing administrator as the initial owner.');
        // Validate every existing table before creating any missing one; no ALTER/DROP or silent adoption.
        $schema=staff_schema(config()['db']['prefix']);$missing=[];
        foreach($schema as $name=>$sql){
            if(one('SELECT TABLE_NAME FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?',[config()['db']['prefix'].$name]))staff_validate_schema($name);
            else $missing[$name]=$sql;
        }
        foreach($missing as $sql)db()->exec($sql);
        if(staff_ready())return;
        staff_transaction(function() use($ownerId): void {
            if((int)query('SELECT COUNT(*) FROM '.table('staff_profiles'))->fetchColumn()!==0||(int)query('SELECT COUNT(*) FROM '.table('staff_invitations'))->fetchColumn()!==0)throw new RuntimeException('Unrecognized staff records already exist. No accounts were overwritten.');
            foreach(all('SELECT id FROM '.table('users').' ORDER BY id') as $u)query('INSERT INTO '.table('staff_profiles').' (user_id,role,enabled,permissions) VALUES (?,?,1,?)',[$u['id'],(int)$u['id']===$ownerId?'owner':'administrator',json_encode(['website.manage','clients.manage'],JSON_THROW_ON_ERROR)]);
            save_setting('staff_schema_version','1');log_event('staff.upgrade','Initial owner '.$ownerId);
        });
    });
}
function staff_owner(#[\SensitiveParameter] string $password): array {
    if(!staff_ready())throw new RuntimeException('Enable administrator access first.');
    $actor=staff_require('staff.manage');
    if(!password_verify($password,$actor['password_hash']))throw new InvalidArgumentException('Your current password is not correct.');
    return $actor;
}
function staff_revoke_credentials(int $id): void {
    if(staff_ready())staff_store()->revoke((string)$id);
    query('DELETE FROM '.table('resets').' WHERE user_id=?',[$id]);
}
function staff_save(int $id,string $name,string $email,string $role,bool $enabled,array $permissions,#[\SensitiveParameter] string $password): int {
    $email=strtolower(trim($email));$name=trim($name);
    if($name===''||strlen($name)>120||strlen($email)>190||!filter_var($email,FILTER_VALIDATE_EMAIL)||!in_array($role,['owner','administrator'],true)||!array_is_list($permissions))throw new InvalidArgumentException('Enter a name, valid email and role.');
    foreach($permissions as $p)if(!is_string($p)||!array_key_exists($p,staff_permissions()))throw new InvalidArgumentException('Unknown administrator permission.');
    return staff_locked(fn()=>staff_transaction(function() use($id,$name,$email,$role,$enabled,$permissions,$password): int {
        staff_owner($password);$old=$id?one('SELECT u.*,p.role,p.enabled FROM '.table('users').' u JOIN '.table('staff_profiles').' p ON p.user_id=u.id WHERE u.id=? FOR UPDATE',[$id]):null;
        if($id&&!$old)throw new InvalidArgumentException('Administrator not found.');
        if($old&&$old['role']==='owner'&&(int)$old['enabled']===1&&$old['password_hash']!==''&&($role!=='owner'||!$enabled)){
            $owners=(int)query('SELECT COUNT(*) FROM '.table('staff_profiles').' p JOIN '.table('users').' u ON u.id=p.user_id WHERE p.role=\'owner\' AND p.enabled=1 AND u.password_hash<>\'\'')->fetchColumn();
            if($owners<=1)throw new InvalidArgumentException('Keep at least one active owner with a completed password setup.');
        }
        $version=bin2hex(random_bytes(16));
        if($old){staff_revoke_credentials($id);query('UPDATE '.table('users').' SET name=?,email=?,auth_version=? WHERE id=?',[$name,$email,$version,$id]);query('UPDATE '.table('staff_profiles').' SET role=?,enabled=?,permissions=? WHERE user_id=?',[$role,(int)$enabled,json_encode(array_values(array_unique($permissions)),JSON_THROW_ON_ERROR),$id]);}
        else{query('INSERT INTO '.table('users').' (name,email,password_hash,auth_version,created_at) VALUES (?,?,\'\',?,?)',[$name,$email,$version,gmdate('Y-m-d H:i:s')]);$id=(int)db()->lastInsertId();query('INSERT INTO '.table('staff_profiles').' (user_id,role,enabled,permissions) VALUES (?,?,?,?)',[$id,$role,(int)$enabled,json_encode(array_values(array_unique($permissions)),JSON_THROW_ON_ERROR)]);}
        log_event($old?'staff.update':'staff.create','Administrator '.$id);return $id;
    }));
}
function staff_invite(int $id,#[\SensitiveParameter] string $password): string {
    return staff_locked(fn()=>staff_transaction(function() use($id,$password): string {
        $actor=staff_owner($password);
        $u=one('SELECT * FROM '.table('users').' WHERE id=? FOR UPDATE',[$id]);
        if(!$u||!staff_profile($u)||(int)$actor['id']===$id)throw new InvalidArgumentException('Choose another enabled administrator.');
        // Recovery requires fresh activation; existing sessions/resets are invalid immediately.
        $version=bin2hex(random_bytes(16));staff_revoke_credentials($id);query('UPDATE '.table('users').' SET password_hash=\'\',auth_version=? WHERE id=?',[$version,$id]);
        $invitation=staff_store()->issue((string)$id,$version);log_event('staff.invite','Administrator '.$id);
        return admin_url('staff-setup').'#token='.$invitation->token;
    }));
}
function staff_activate(#[\SensitiveParameter] string $token,#[\SensitiveParameter] string $password): void {
    validate_password($password);$hash=password_hash($password,PASSWORD_DEFAULT);
    $ok=staff_locked(function() use($token,$hash): bool {
        if(!staff_ready())return false;
        return staff_store()->redeem($token,function(PDO $db,string $id,string $version) use($hash): bool {
            $u=one('SELECT * FROM '.table('users').' WHERE id=? FOR UPDATE',[$id]);
            if(!$u||!staff_profile($u)||!hash_equals($version,$u['auth_version']))return false;
            query('UPDATE '.table('users').' SET password_hash=?,auth_version=? WHERE id=?',[$hash,bin2hex(random_bytes(16)),$id]);query('DELETE FROM '.table('resets').' WHERE user_id=?',[$id]);log_event('staff.activate','Administrator '.$id);return true;
        });
    });
    if(!$ok)throw new InvalidArgumentException('This setup link expired or is no longer available. Ask an owner for a new one.');
}
function staff_account_save(int $id,string $name,string $email,#[\SensitiveParameter] string $current,#[\SensitiveParameter] string $password): string {
    if(trim($name)===''||strlen($name)>120||strlen($email)>190||!filter_var($email,FILTER_VALIDATE_EMAIL))throw new InvalidArgumentException('A name and valid email are required.');
    if($password!=='')validate_password($password);
    return staff_locked(fn()=>staff_transaction(function() use($id,$name,$email,$current,$password): string {
        $u=require_admin();if((int)$u['id']!==$id||!password_verify($current,$u['password_hash']))throw new InvalidArgumentException('Your current password is not correct.');
        $version=bin2hex(random_bytes(16));staff_revoke_credentials($id);query('UPDATE '.table('users').' SET name=?,email=?,password_hash=?,auth_version=? WHERE id=?',[trim($name),strtolower($email),$password===''?$u['password_hash']:password_hash($password,PASSWORD_DEFAULT),$version,$id]);log_event('account.update');return $version;
    }));
}
function staff_reset(#[\SensitiveParameter] string $token,#[\SensitiveParameter] string $password): void {
    validate_password($password);if(!preg_match('/^[a-f0-9]{64}$/D',$token))throw new InvalidArgumentException('This reset link is not valid.');
    $hash=password_hash($password,PASSWORD_DEFAULT);
    staff_locked(fn()=>staff_transaction(function() use($token,$hash): void {
        $r=one('SELECT * FROM '.table('resets').' WHERE token_hash=? FOR UPDATE',[hash('sha256',$token)]);
        if(!$r||(int)$r['expires']<=time())throw new InvalidArgumentException('This link expired or has already been used. Request a new one.');
        $u=one('SELECT * FROM '.table('users').' WHERE id=? FOR UPDATE',[$r['user_id']]);
        if(!$u||$u['password_hash']===''||!staff_profile($u))throw new InvalidArgumentException('This reset link is no longer available.');
        staff_revoke_credentials((int)$u['id']);query('UPDATE '.table('users').' SET password_hash=?,auth_version=? WHERE id=?',[$hash,bin2hex(random_bytes(16)),$u['id']]);log_event('staff.password_reset','Administrator '.$u['id']);
    }));
}
function staff_reset_token(string $email): ?array {
    return staff_locked(fn()=>staff_transaction(function() use($email): ?array {
        $u=one('SELECT * FROM '.table('users').' WHERE email=? FOR UPDATE',[$email]);
        if(!$u||$u['password_hash']===''||!staff_profile($u))return null;
        $token=bin2hex(random_bytes(32));query('INSERT INTO '.table('resets').' (token_hash,user_id,expires) VALUES (?,?,?)',[hash('sha256',$token),$u['id'],time()+3600]);return ['email'=>$u['email'],'token'=>$token];
    }));
}
function staff_view_permission(string $view): ?string {
    if(in_array($view,['login','forgot','reset','staff-setup','security'],true))return null;
    if(in_array($view,['staff','payment-settings','payment-trials','payment-notifications'],true))return 'staff.manage';
    if(in_array($view,['payments','invoice-payments'],true))return 'payments.manage';
    if($view==='support')return 'support.login';
    if(in_array($view,['catalog','catalog-invoice'],true))return 'catalog.manage';
    if(in_array($view,['email','health','studio-upgrade'],true))return 'staff.manage';
    if(in_array($view,['studio-clients','studio-job','deliveries','activity'],true))return 'clients.manage';
    return 'website.manage';
}
function staff_action_permission(string $action): ?string {
    if(in_array($action,['logout','account_save'],true))return null;
    if($action==='support_start')return 'support.login';
    if(in_array($action,['payments_migrate','payments_ledger_setup','payments_ledger_reverse','payments_save','payments_clear','payments_verify','payments_trial_setup','payments_trial_submit','payments_trial_verify','payments_notification_setup','payments_notification_configure','payments_notification_verify'],true))return 'staff.manage';
    if(str_starts_with($action,'payments_'))return 'payments.manage';
    if(in_array($action,['delivery_setup','delivery_publish'],true))return 'staff.manage';
    if($action==='activity_setup')return 'staff.manage';
    if($action==='activity_mark')return 'clients.manage';
    if($action==='delivery_upload')return 'clients.manage';
    if($action==='catalog_migrate')return 'staff.manage';
    if(str_starts_with($action,'catalog_'))return 'catalog.manage';
    if(in_array($action,['support_migrate','support_policy'],true))return 'staff.manage';
    if(str_starts_with($action,'staff_')||in_array($action,['email_save','email_test','installer_cleanup','storage_repair','clear_limits','media_cleanup','studio_migrate'],true))return 'staff.manage';
    if(in_array($action,['studio_client','studio_invite','studio_job','studio_message','studio_publish','studio_upload','studio_invoice','studio_paid'],true))return 'clients.manage';
    return 'website.manage';
}
function staff_home(array $user): string {
    return staff_can('website.manage',$user)?'dashboard':(staff_can('clients.manage',$user)?'studio-clients':(staff_can('catalog.manage',$user)?'catalog':(staff_can('support.login',$user)?'support':'security')));
}
